/*
GROUP MEMBERS:
1. Nirdesh Sakh -- ID: 1001750259
2. Sanyogita Piya -- ID: 1001743446

Brief description:
The assignment is about implementation of our own malloc and free. We will 
implement the library that perform heap management.

Compile command:
For Next Fit: 
   env LD_PRELOAD=lib/libmalloc-nf.so tests/ffnf
For Best Fit:
   env LD_PRELOAD=lib/libmalloc-bf.so tests/bfwf
For Worst Fit:
   env LD_PRELOAD=lib/libmalloc-wf.so tests/bfwf
*/

#include <assert.h>
#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include <stdlib.h>
#include<limits.h>
#include<string.h>

//THIS PART OF CODE IS GIVEN TO US
#define ALIGN4(s)         (((((s) - 1) >> 2) << 2) + 4)
#define BLOCK_DATA(b)      ((b) + 1)
#define BLOCK_HEADER(ptr)   ((struct _block *)(ptr) - 1)


static int atexit_registered = 0;
static int num_mallocs       = 0;
static int num_frees         = 0;
static int num_reuses        = 0;
static int num_grows         = 0;
static int num_splits        = 0;
static int num_coalesces     = 0;
static int num_blocks        = 0;
static int num_requested     = 0;
static int max_heap          = 0;

/*
 *  \brief printStatistics
 *
 *  \param none
 *
 *  Prints the heap statistics upon process exit.  Registered
 *  via atexit()
 *
 *  \return none
 */
void printStatistics( void )
{
  printf("\nheap management statistics\n");
  printf("mallocs:\t%d\n", num_mallocs );
  printf("frees:\t\t%d\n", num_frees );
  printf("reuses:\t\t%d\n", num_reuses );
  printf("grows:\t\t%d\n", num_grows );
  printf("splits:\t\t%d\n", num_splits );
  printf("coalesces:\t%d\n", num_coalesces );
  printf("blocks:\t\t%d\n", num_blocks );
  printf("requested:\t%d\n", num_requested );
  printf("max heap:\t%d\n", max_heap );
}

struct _block 
{
   size_t  size;         /* Size of the allocated _block of memory in bytes */
   struct _block *prev;  /* Pointer to the previous _block of allcated memory   */
   struct _block *next;  /* Pointer to the next _block of allcated memory   */
   bool   free;          /* Is this _block free?                     */
   char   padding[3];
};


struct _block *heapList = NULL; /* Free list to track the _blocks available */

/*
 * \brief findFreeBlock
 *
 * \param last pointer to the linked list of free _blocks
 * \param size size of the _block needed in bytes 
 *
 * \return a _block that fits the request or NULL if no free _block matches
 *
 * \Implement Next Fit
 * \Implement Best Fit
 * \Implement Worst Fit
 */
struct _block *findFreeBlock(struct _block **last, size_t size) 
{
   struct _block *curr = heapList;

#if defined FIT && FIT == 0
   /* First fit */
   while (curr && !(curr->free && curr->size >= size)) 
   {
      *last = curr;
      curr  = curr->next;
   }
#endif

#if defined BEST && BEST == 0
   //REQUIREMENT 2: Implementation of best fit algorithm
   //Concept: The block with the smallest difference to the size requested will be chosen
   int spaceRemaining=INT_MAX;
   struct _block* bestFit=NULL;
   while(curr)
   {
      if(curr->free)
      {
         if(curr->size>=size)
         {
            if((int)(curr->size - size) < spaceRemaining)
            {
               bestFit=curr;
               spaceRemaining=curr->size - size;
            }

         }
        
      }
      *last=curr;
      curr=curr->next;
   }
   curr=bestFit;
#endif

#if defined WORST && WORST == 0
   //REQUIREMENT 2: Implementation of worst fit algorithm
   //Concept: Biggest block of memory available should be choosen
   int spaceRemaining=INT_MIN;
   struct _block* worstFit=NULL;
   while(curr)
   {
      if(curr->free)
      {
         if(curr->size>=size)
         {
            if((int)(curr->size - size) > spaceRemaining)
            {
               worstFit=curr;
               spaceRemaining=curr->size - size;
            }
         }
         
      }
      curr=curr->next;
   }
   curr=worstFit;
#endif

#if defined NEXT && NEXT == 0
   //REQUIREMENT 2: Implementation of next fit algorithm
   //Concept: The next available block will be choosen
   if(*last!=NULL)
   {
      curr=(*last)->next;
   }
   while (curr && !(curr->free && curr->size >= size)) 
   {
      *last = curr;
      curr  = curr->next;
   }

#endif

   return curr;
}

/*
 * \brief growheap
 *
 * Given a requested size of memory, use sbrk() to dynamically 
 * increase the data segment of the calling process.  Updates
 * the free list with the newly allocated memory.
 *
 * \param last tail of the free _block list
 * \param size size in bytes to request from the OS
 *
 * \return returns the newly allocated _block of NULL if failed
 */
struct _block *growHeap(struct _block *last, size_t size) 
{
   /* Request more space from OS */
   struct _block *curr = (struct _block *)sbrk(0);
   struct _block *prev = (struct _block *)sbrk(sizeof(struct _block) + size);

   assert(curr == prev);

   /* OS allocation failed */
   if (curr == (struct _block *)-1) 
   {
      return NULL;
   }

   /* Update heapList if not set */
   if (heapList == NULL) 
   {
      heapList = curr;
   }

   /* Attach new _block to prev _block */
   if (last) 
   {
      last->next = curr;
   }

   /* Update _block metadata */
   curr->size = size;
   curr->next = NULL;
   curr->free = false;
   /*REQUIREMENT 3: Tracking the counters for grows, blocks
     and max heap */
   num_grows=num_grows+1;
   max_heap=max_heap+curr->size;
   return curr;
}

/*
 * \brief malloc
 *
 * finds a free _block of heap memory for the calling process.
 * if there is no free _block that satisfies the request then grows the 
 * heap and returns a new _block
 *
 * \param size size of the requested memory in bytes
 *
 * \return returns the requested memory allocation to the calling process 
 * or NULL if failed
 */
void *malloc(size_t size) 
{
   //REQUIREMENT 3: Tracking counters for total memory requested
   num_requested=num_requested+size;
   if( atexit_registered == 0 )
   {
      atexit_registered = 1;
      atexit( printStatistics );
   }

   /* Align to multiple of 4 */
   size = ALIGN4(size);

   /* Handle 0 size */
   if (size == 0) 
   {
      return NULL;
   }

   /* Look for free _block */
   struct _block *last = heapList;
   struct _block *next = findFreeBlock(&last, size);

   /* TODO: Split free _block if possible */
   //REQUIREMENT 1 is removed from assignment

   /* Could not find free _block, so grow heap */
   if (next == NULL) 
   {
      next = growHeap(last, size);
   }
   else
   {
      //If the program doesnt grows heap it reuses the same memory
      //REQUREMENT 3: Tracking counter for reuses
      num_reuses=num_reuses+1;
      if(num_blocks>0)
      {
         num_blocks=num_blocks-1;
      }
   }

   /* Could not find free _block or grow heap, so just return NULL */
   if (next == NULL) 
   {
      return NULL;
   }
   
   /* Mark _block as in use */
   next->free = false;
   //REQUIREMENT 3: Tracking counter for successful mallocs
   num_mallocs=num_mallocs+1;
   /* Return data address associated with _block */
   
   return BLOCK_DATA(next);
}
/*
 * \brief realloc
 *
 * resizes the memory block that was previously allocated 
 *
 * \param *ptr pointer to a memory block previously allocated
 * \param size size of the requested memory in bytes
 *
 * \return returns the requested memory allocation to the calling process 
 * or NULL if failed
 */
void* realloc(void *ptr, size_t size)
{
   //REQUIREMENT 5: Implementation of realloc
   void* address;
   address = malloc(size);
   if (address)
   {
      memcpy(address, ptr, size);
   }
   free(ptr);
   return (address);
}
/*
 * \brief calloc
 *
 * allocates the requested memory and returns a pointer
 *
 * \param nmemb number of elements to be allocated
 * \param size size of the requested memory in bytes
 *
 * \return returns the requested memory allocation to the calling process 
 * or NULL if failed
 */
void* calloc(size_t nmemb,size_t size)
{
   //REQUIREMENT 5: Implementation of calloc
   void* address;
   size_t total= nmemb*size;
   address = malloc(total);
   if (address)
   {
      memset(address,0,total);
   }
   return (address);
}
/*
 * \brief free
 *
 * frees the memory _block pointed to by pointer. if the _block is adjacent
 * to another _block then coalesces (combines) them
 *
 * \param ptr the heap memory to free
 *
 * \return none
 */
void free(void *ptr) 
{
   //REQUIREMENT 3: Tracking the counter for frees and blocks
   num_frees=num_frees+1;
   num_blocks=num_blocks+1;
   if (ptr == NULL) 
   {
      return;
   }

   /* Make _block as free */
   struct _block *curr = BLOCK_HEADER(ptr);
   assert(curr->free == 0);
   curr->free = true;

   /* TODO: Coalesce free _blocks if needed */
   //REQUIREMENT 1 is removed from assignment
}

/* vim: set expandtab sts=3 sw=3 ts=6 ft=cpp: --------------------------------*/